﻿
public class ClothingSlotImage : HighlightObject
{
}
